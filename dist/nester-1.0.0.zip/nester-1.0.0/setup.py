from distutils.core import setup

setup(
		name		= 'nester',
		version		= '1.0.0',
		py_modules	= ['nester'],
		author		= 'Seven Guo',
		author_email= 'xingqiqigqf@163.com',
		url			= 'http://weibo.com/guoqingfa',
		description	= 'just a test'
)